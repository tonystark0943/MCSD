package nm;
import java.util.Scanner;
public class Fact_Rec {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number :");
		int n = sc.nextInt();
		if(n<0)
		{
			System.out.println("Enter a valid number!");
		}
		else
		{
			System.out.println("The factorial is "+fact(n));
		}

	}
	public static int fact(int n)
	{
		if (n==0)
		{
			return 1;
		}
		else
		{
			return n * fact(n-1);
		}
	}

}
