package nm;
import java.util.Scanner;
public class Factorial {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n, f=1;
		System.out.println("Enter a positive number:");
		n = sc.nextInt();
		if (n<=1)
		{
			System.out.println("Please enter a valid number!");
			System.exit(0);
		}
		else
		{
			for(int i=1;i<=n;i++)
			{
				f = f*i;
			}
			System.out.println("The factorial of "+n+" is "+f);
		}

	}

}
