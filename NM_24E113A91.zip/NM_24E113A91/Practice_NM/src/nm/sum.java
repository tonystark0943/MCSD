package nm;
import java.util.Scanner;
public class sum {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number :");
		int n = sc.nextInt();
		if (n<0)
		{
			System.out.println("Please enter a valid number!");
		}
		else
		{
			int sum = sum_rec(n);
			System.out.println("The sum is "+sum);
		}

	}
	public static int sum_rec(int n)
	{
		if (n==0)
		{
			return 0 ;
		}
		else
		{
			return n +sum_rec(n-1);
		}
	}

}
