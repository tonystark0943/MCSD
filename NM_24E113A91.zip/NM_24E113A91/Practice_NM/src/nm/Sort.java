package nm;

public class Sort {

	public static void main(String[] args) {
		int A[] = {2,0,2,1,1,0};
		int l = A.length-1;
		int temp = A[0];
		for (int i = 0;i<=l;i++)
		{
			if (A[i]>=temp)
			{
				
			}
		}
		
	}

}
