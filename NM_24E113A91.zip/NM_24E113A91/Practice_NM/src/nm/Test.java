package nm;
import java.util.Scanner;
	public class Test {
		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			int n, s = 0;
			System.out.println("Please enter array index:");
			n = sc.nextInt();
			int A[] = new int[n];
			if (n<=0)
			{
				System.out.println("Please enter a valid number!");
				System.exit(0);
			}
			for (int i = 0;i<n;i++)
			{
				System.out.println("Please enter a number:");
				A[i] = sc.nextInt();
			}
			for (int i = 0;i<n;i++)
			{
				s = s + A[i];
			}
			System.out.println("The sum of n numbers :"+s);
			
		}

	}


