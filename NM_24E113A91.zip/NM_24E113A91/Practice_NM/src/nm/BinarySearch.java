package nm;
import java.util.Scanner;
public class BinarySearch {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int t, l,m,r,c=0;
		int A[] = {1,2,3,4,5,6};
		System.out.println("Please enter number to search:");
		t = sc.nextInt();
		l = 0; m = (A.length-1)/2; r = A.length-1;
		if (t>m)
		{
			for(int i = m+1;i<=r;i++)
			{
				if (t == A[i])
				{
					System.out.println("Number at found index "+i);
					c += 1;
				}
			}
		}
		else if(t<m)
		{
			for(int i = 0;i<m;i++)
			{
				if (t == A[i])
				{
					System.out.println("Number at found index "+i);
					c += 1;
				}
			}
		}
		else if (t == m)
		{
			System.out.println("Number found at index "+m);
			c += 1;
		}
		if (c == 0)
		{
			System.out.println("Number not found!");
		}
		
		
	}

}
