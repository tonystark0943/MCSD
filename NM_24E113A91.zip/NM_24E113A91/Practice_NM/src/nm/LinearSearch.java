package nm;
import java.util.Scanner;
public class LinearSearch {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n, t,i=0, m=0;
		System.out.println("Please enter a positive number(size of array):");
		n = sc.nextInt();
		if (n<0)
		{
			System.out.println("Please enter a valid number!");
			System.exit(0);
		}
		else
		{
			int A[] = new int[n];
			for(i = 0;i<n;i++)
			{
				System.out.println("Please enter a number:");
				A[i] = sc.nextInt();
			}
			System.out.println("Please enter the number to search:");
			t = sc.nextInt();
			for(i = 0;i<n;i++)
			{
				if (A[i] == t)
				{
					System.out.println("Number found at index "+i);	
					m += 1;
				}	
			}
			if (m == 0)
			{
				System.out.println("Number not found");
			}
		}

	}

}
