package nm;
import java.util.Scanner;
public class Fibonacci {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n, f1 = 0, f2 = 1, f3 = 0;
		System.out.println("Please enter a positive number:");
		n = sc.nextInt();
		if (n<0)
		{
			System.out.println("Please enter a valid number!");
			System.exit(0);
		}
		else
		{
			System.out.println("The fibonacci numbers are ");
			System.out.print("0 1");
			for(int i = 0;i<=(n-2); i++)
			{
				f3 = f1 + f2;
				f1 = f2;
				f2 = f3;
				System.out.print(" "+f3);
			}
		}

	}

}
