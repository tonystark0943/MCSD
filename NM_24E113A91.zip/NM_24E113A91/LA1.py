#LAB ASSIGNMENT 1
#Name - Nippani Meghana
#Registration Number - 24E113A91
#Serial Number - 16

#Objective 1
'''
import math
def calc():
    print("Press 1 for addition")
    print("Press 2 for subtraction ")
    print("Press 3 for multiplication ") 
    print("Press 4 for division ")
    print("Press 5 for exponential ")
    print("Press 6 for tan ")
    print("Press 7 for sin ")
    print("Press 8 for cos ") 
    print("Press 9 for factorial ")
    print("Press 10 for log :")
    ch = int(input("Enter your choice: "))
    a = int(input("Enter a no.:"))
    b = int(input("Enter a no.:"))
    if ch == 1:
        return a + b
    elif ch == 2:
        return a - b
    elif ch == 3:
        return a * b
    elif ch == 4:
        return a/b
    elif ch == 5:
        return math.pow(a,b)
    elif ch == 6:
        return math.tan(math.radians(a))
    elif ch == 7:
        return math.sin(math.radians(a))
    elif ch == 8:
        return math.cos(math.radians(a))
    elif ch == 9:
        return math.factorial(a)
    elif ch == 10:
        math.log10(a)
    else:
        print("Invalid Choice!")
        return

res = calc()
print("The result is", res)
'''
#Objective 2
'''
def fibo(n):
    if n<=0:
        print("Invalid number!")
        return
    elif n == 1:
        print("0")
    else:
        f1 = 0
        f2 = 1
        print("0 1", end = " ")
        for _ in range(2,n):
            f3 = f1 + f2
            print(f3,end =" ")
            f1 = f2
            f2 = f3
    return

n = int(input("Enter a positive number:"))
fibo(n)


#Objective 3
def largest(a,b):
    if a==b:
        print("Both are equal!") 
    elif a>b:
        print("First number is greater than the second number") 
    else:
        print("First number is less than the second")
    return
    
a = int(input("Enter a no.:"))
b = int(input("Enter a no.:"))
largest(a,b)


#Objective 4
for _ in range(1,11):
    for i in range(1, _ + 1):
        print(chr(64+i), end =" ")

    print()


#Objective 5
for _ in range(1,11):
    for i in range(1,12-_):
        print(_, end = " ")
    print()  


#Objective 6
money = int(input("Enter amount :"))
if money>=0:
    print("Number of 100s are ", money//100)
    money = money%100
    print("Number of 50s are ",money//50)
    money = money%50
    print("Number of 10s are ",money//10)
    money = money%10
else:
    print("Please enter a valid amount")
'''

#Objective 7
'''
def gcd(x,y):
    if x>y:
        x,y = y, x%y
        gcd = x
    else:
        y,x = x, y%x
        gcd= y
    return gcd

a = int(input("Enter a no.:"))
b = int(input("Enter a no.:"))
print("The gcd is ", gcd(a,b))
'''

#Objective 8
'''
def overtime_pay():
    ovt = []
    for _ in range(1,11):
        hr = int(input("Enter the hours worked:"))
        if (hr>40):
            ovt.append((hr-40)*12)
    return ovt

pay = overtime_pay()
print("The total amount paid is ", sum(pay))
'''

#Objective 9



