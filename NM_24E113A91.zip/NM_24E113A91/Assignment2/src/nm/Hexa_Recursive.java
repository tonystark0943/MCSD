package nm;
import java.util.Scanner;
public class Hexa_Recursive {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number :");
		int n = sc.nextInt();
		int temp = n;
		String hex = "";
		while(temp>0)
		{
			char c;
			int remain = temp%16;
			System.out.println("Remainder = "+remain);
			if (remain>9 && remain<=15)
			{
				c = (char)(remain + 55);
				hex = hex + c;
			}
			else
			{
				hex = hex+remain;
			}
			temp = temp/16;
		}
		
		System.out.println("Hexadecimal value is "+ hex);
	}

}
