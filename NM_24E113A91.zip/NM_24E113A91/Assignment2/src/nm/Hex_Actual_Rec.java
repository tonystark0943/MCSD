package nm;
import java.util.Scanner;
public class Hex_Actual_Rec {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number :");
		int n = sc.nextInt();
		String hex = hex_rec(n);
		String rev="";
		for (int i = hex.length()-1;i>=0;i--)
		{
			rev += hex.charAt(i);
		}
		System.out.println("Hexadecimal value is "+ rev);
	}
	public static String hex_rec(int n)
	{
		String hex = "";
		if(n==0)
		{
			return "";
		}
		else
		{
			char c;
			int remain = (int)n%16;
			System.out.println("Remainder = "+remain);
			if (remain>9 && remain<=15)
			{
				c = (char)(remain + 55);
				hex = hex + c;
			}
			else
			{
				hex = hex+remain;
			}
			return hex + hex_rec(n/16);
		}
	}

}
