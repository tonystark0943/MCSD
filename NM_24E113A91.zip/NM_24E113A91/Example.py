'''
a = 10
b = 20
a,b = b,a
print(a)
print(b)

x = 10
y = "20"
print(x + int(y))

age = int(input("Enter your age:"))
if age>=18:
    print("You can vote!")
else:
    print(f" Wait for {18-age} years to vote")

str = input("Enter a string:")
new_str = ""
for _ in str:
    if _ in 'aeiouAEIOU':
        continue
    else:
        new_str += _
print(new_str)
'''

def calc(a,b,ch):
    if ch == 1:
        return a + b
    elif ch == 2:
        return a - b
    elif ch == 3:
        return a * b
    elif ch == 4:
        return a/b
    else:
        print("Invalid Choice!")
        return

ch = int(input("Press 1 for addition, 2 for subtraction, 3 for multiplication, 4 for division:"))
a = int(input("Enter a no.:"))
b = int(input("Enter a no.:"))
res = calc(a,b,ch)
print("The result is", res)

